package com.itu.sivas_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SivasAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SivasAppApplication.class, args);
	}

}
